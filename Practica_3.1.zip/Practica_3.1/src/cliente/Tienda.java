package cliente;

import target.PasarelaPago;

public class Tienda {
    private final PasarelaPago pasarela;

    public Tienda(PasarelaPago pasarela) {
        this.pasarela = pasarela;
    }

    public void vender(double precio, String moneda) {
        System.out.println("[Tienda] Vendiendo producto por " + precio + " " + moneda);
        pasarela.procesarPago(precio, moneda);
    }
}