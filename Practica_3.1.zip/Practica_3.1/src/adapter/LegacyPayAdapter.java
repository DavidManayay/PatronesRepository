package adapter;

import adaptee.LegacyPayLib;
import target.PasarelaPago;

public class LegacyPayAdapter implements PasarelaPago {
    private final LegacyPayLib legacyLib;

    public LegacyPayAdapter(LegacyPayLib legacyLib) {
        this.legacyLib = legacyLib;
    }

    @Override
    public void procesarPago(double monto, String moneda) {
        int centavos = (int) (monto * 100);
        System.out.println("[Adapter] Convirtiendo monto: " + monto + " -> " + centavos + " centavos");
        legacyLib.realizarTransaccion(centavos, moneda);
    }
}