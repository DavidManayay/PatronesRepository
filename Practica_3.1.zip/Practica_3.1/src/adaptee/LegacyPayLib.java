package adaptee;

public class LegacyPayLib {
    public void realizarTransaccion(int centavos, String codigoDivisa) {
        System.out.println("[LegacyPayLib] Procesando " + centavos + " centavos en divisa: " + codigoDivisa);
    }
}