import adaptee.LegacyPayLib;
import adapter.LegacyPayAdapter;
import cliente.Tienda;
import target.PasarelaPago;

public class Main {
    public static void main(String[] args) {

        PasarelaPago pasarelaModerna = new PasarelaPago() {
            @Override
            public void procesarPago(double monto, String moneda) {
                System.out.println("[Pasarela Moderna] Procesando pago instantáneo de "
                        + monto + " " + moneda + " vía API Rest.");
            }
        };

        System.out.println("=== CLIENTE USANDO PASARELA MODERNA ===");
        Tienda tiendaOnline = new Tienda(pasarelaModerna);
        tiendaOnline.vender(150.50, "PEN");



        LegacyPayLib libreriaVieja = new LegacyPayLib();

        PasarelaPago adaptador = new LegacyPayAdapter(libreriaVieja);

        System.out.println("=== CLIENTE USANDO PASARELA ANTIGUA (VIA ADAPTER) ===");
        Tienda tiendaFisica = new Tienda(adaptador);

        tiendaFisica.vender(50.80, "USD");
    }
}